import express from "express";
import { userController } from "./user.controller";
import { validation } from "../../middleware/validation";
import { userValidation } from "./user.validation";
import auth from "../../middleware/auth";
import { user_role } from "./user.const";
const router = express.Router();
router.post(
  "/create-user",
  validation(userValidation.userValidationSchema),
  userController.createUser,
);
export const userRoute = router;
