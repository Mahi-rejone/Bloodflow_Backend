import { Model, Types } from "mongoose";
import { user_role } from "./user.const";

export type TUser = {
  _id: Types.ObjectId;
  name: string;
  email: string;
  password: string;
  role: "Admin" | "Staff" | "Teacher" | "Student";
  status: "active" | "blocked";
  passwordChangedAt?: Date;
  needsPasswordChange: boolean;
  isDeleted: boolean;
};
export type TUser_Role = (typeof user_role)[keyof typeof user_role];
export interface UserModel extends Model<TUser> {
  isUserExist(username: string): Promise<TUser>;
  isPasswordMatched(plainText: string, hashedPass: string): Promise<boolean>;
  isTokenIssuedBeforePasswordChanged(
    passwordChangedTimeStamp: Date,
    tokenIssuedTimeStamp: number,
  ): boolean;
}
