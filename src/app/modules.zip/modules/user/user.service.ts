import httpStatus from 'http-status'
import AppError from '../../error/AppError'
import { TUser } from './user.interface'
import { User } from './user.model'

const createUserIntoDB = async ({ ...rest }: TUser) => {
  if (await User.isUserExist(rest.email)) {
    throw new AppError(httpStatus.CONFLICT, 'Username already exists!')
  }
  const result = await User.create(rest)
  if (result) return null
}


export const userServices = {
  createUserIntoDB
}
