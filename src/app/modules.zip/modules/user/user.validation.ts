import { z } from "zod";
import { user_role, user_status } from "./user.const";

const userValidationSchema = z.object({
  body: z.object({
    name: z.string(),
    email: z.string(),
    password: z.string(),
    role: z.enum([
      user_role.admin,
      user_role.teacher,
      user_role.staff,
      user_role.student,
    ]),
    status: z
      .enum([user_status.active, user_status.blocked])
      .default(user_status.active),
    LicenseNo: z.string().optional(),
    permittedContries: z.string().array().optional(),
  }),
});

const userUpdateValidation = z.object({
  body: z.object({
    role: z
      .enum([
        user_role.admin,
        user_role.teacher,
        user_role.staff,
        user_role.student,
      ])
      .optional(),
    status: z.enum([user_status.active, user_status.blocked]).optional(),
  }),
});

export const userValidation = {
  userValidationSchema,
  userUpdateValidation,
};
