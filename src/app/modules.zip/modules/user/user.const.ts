export const user_role = {
  admin: "Admin",
  staff: "Staff",
  teacher: "Teacher",
  student: "Student",
} as const;

export const user_status = {
  active: "active",
  blocked: "blocked",
} as const;
