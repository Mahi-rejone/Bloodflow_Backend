import { TItem } from "./item.interface";
import { Item } from "./item.model";

const createItemIntoDB = async (payload: TItem) => {
  const result = await Item.create(payload);
  if (result) return result?.itemName;
};

const getItem = async () => {
  const result = await Item.find({});
  if (result) return result;
};
const getSingleItem = async (id: string) => {
  const result = await Item.findById(id);
  if (result) return result;
};
const updateItem = async (id: string, payload: Partial<TItem>) => {
  const result = await Item.findByIdAndUpdate(id, payload);
  if (result) return result;
};

export const itemServices = {
  createItemIntoDB,
  getItem,
  getSingleItem,
  updateItem,
};
