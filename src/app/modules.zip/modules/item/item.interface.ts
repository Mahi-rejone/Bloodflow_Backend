import { itemStatus } from "./item.const";

export type TContactValues = {
  email: string;
  whatsapp: string;
};
export type TItem = {
  itemName: string;
  category: string;
  description: string;
  lastSeenLocation: string;
  currentKeptLocation: string;
  dateLost: string;
  timeLost: string;
  image: string;
  status: (typeof itemStatus)[keyof typeof itemStatus];
  contactMethods: string[];
  contactValues: TContactValues;
  isDeleted: boolean;
};
