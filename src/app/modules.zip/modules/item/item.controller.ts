import catchAsync from "../../utils/catchAsync";
import sendResponse from "../../utils/sendResponse";
import { itemServices } from "./item.service";
import httpStatus from "http-status";

const createItem = catchAsync(async (req, res) => {
  const data = req.body;
  const result = await itemServices.createItemIntoDB(data);
  sendResponse(res, {
    success: true,
    statusCode: httpStatus.CREATED,
    message: "Item successfully created",
    data: result,
  });
});

const getItem = catchAsync(async (req, res) => {
  const result = await itemServices.getItem();
  sendResponse(res, {
    success: true,
    statusCode: httpStatus.OK,
    message: "Items successfully retrieved",
    data: result,
  });
});
const getSingleItem = catchAsync(async (req, res) => {
  const id = req.params.id;
  const result = await itemServices.getSingleItem(id as string);
  sendResponse(res, {
    success: true,
    statusCode: httpStatus.OK,
    message: "Item successfully retrieved",
    data: result,
  });
});

const updateItem = catchAsync(async (req, res) => {
  const data = req.body;
  const id = req.params.id;
  const result = await itemServices.updateItem(id as string, data);
  sendResponse(res, {
    success: true,
    statusCode: httpStatus.OK,
    message: "Item successfully updated",
    data: result,
  });
});

export const itemController = {
  createItem,
  getItem,
  getSingleItem,
  updateItem,
};
