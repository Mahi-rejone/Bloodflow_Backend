export const itemStatus = {
  lost: "lost",
  found: "found",
} as const;
