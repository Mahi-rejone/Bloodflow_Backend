import express from "express";
import auth from "../../middleware/auth";
import { user_role } from "../user/user.const";
import { itemController } from "./item.controller";
const router = express.Router();
router.post(
  "/create-item",
  auth(user_role.admin, user_role.teacher, user_role.staff, user_role.student),
  itemController.createItem,
);
router.get(
  "/get-item",
  auth(user_role.admin, user_role.teacher, user_role.staff, user_role.student),
  itemController.getItem,
);
router.get(
  "/get-single-item/:id",
  auth(user_role.admin, user_role.teacher, user_role.staff, user_role.student),
  itemController.getSingleItem,
);
router.put(
  "/update-item/:id",
  auth(user_role.admin, user_role.teacher, user_role.staff, user_role.student),
  itemController.getSingleItem,
);
export const itemRoute = router;
