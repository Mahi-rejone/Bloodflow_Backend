import httpStatus from "http-status";
import AppError from "../../error/AppError";
import { TLogin } from "./auth.interface";
import { User } from "../user/user.model";
import { config } from "../../config/config";
import { createToken, verifyToken } from "../../utils/auth.utils.";
import { Types } from "mongoose";
import { JwtPayload } from "jsonwebtoken";
import bcrypt from "bcrypt";
import { TUser, TUser_Role } from "../user/user.interface";
import ms from "ms";

const login = async (payload: TLogin) => {
  const user: TUser = await User.isUserExist(payload?.email);
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, "user not found!");
  }
  if (user?.status === "blocked") {
    throw new AppError(httpStatus.BAD_REQUEST, "This user is blocked!");
  }
  if (user?.isDeleted) {
    throw new AppError(httpStatus.NOT_FOUND, "user not found!");
  }
  if (!(await User.isPasswordMatched(payload?.password, user?.password))) {
    throw new AppError(httpStatus.FORBIDDEN, "Password do not matched!");
  }

  const find = await User.findOne({ email: user?.email })
    .select("-password -createdAt -updatedAt -__v")
    .lean();

  const jwtPayload: {
    _id: Types.ObjectId | undefined;
    role: TUser_Role;
    email: string | undefined;
  } = {
    _id: find?._id,
    role: find?.role as TUser_Role,
    email: find?.email,
  };
  const accessToken = createToken(
    jwtPayload,
    config.access_secret as string,
    config.access_expires as ms.StringValue,
  );
  const refreshToken = createToken(
    jwtPayload,
    config.refresh_secret as string,
    config.refresh_expires as ms.StringValue,
  );
  return {
    accessToken,
    refreshToken,
    needsPasswordChange: user?.needsPasswordChange,
  };
};

const RefreshToken = async (refreshToken: string) => {
  const decode = verifyToken(refreshToken, config?.refresh_secret as string);
  const { _id, username, email, iat } = decode;
  const user = await User.findOne({
    _id: _id,
    username: username,
    email: email,
  });
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, "user not found!");
  }
  if (user?.isDeleted) {
    throw new AppError(httpStatus.FORBIDDEN, "This user is Deleted!");
  }
  if (user?.status !== "active") {
    throw new AppError(httpStatus.FORBIDDEN, "This user is blocked!");
  }
  if (
    user?.passwordChangedAt &&
    User.isTokenIssuedBeforePasswordChanged(
      user?.passwordChangedAt,
      iat as number,
    )
  ) {
    throw new AppError(
      httpStatus.UNAUTHORIZED,
      "You do not have the necessary permissions to access this resource.",
    );
  }
  const jwtPayload: {
    _id: Types.ObjectId | undefined;
    role: TUser_Role;
    email: string | undefined;
  } = {
    _id: user?._id,
    role: user?.role as TUser_Role,
    email: user?.email,
  };
  const accessToken = createToken(
    jwtPayload,
    config?.access_secret as string,
    config.access_expires as ms.StringValue,
  );
  return { accessToken };
};

const ChangePassword = async (
  userData: JwtPayload,
  password: { currentPassword: string; newPassword: string },
) => {
  const user = await User.isUserExist(userData?.email);
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, "user not found!");
  }
  if (
    !(await User.isPasswordMatched(password?.currentPassword, user?.password))
  ) {
    throw new AppError(httpStatus.FORBIDDEN, "Password do not matched!");
  }
  const newHashedPassword = await bcrypt.hash(
    password?.newPassword,
    Number(config.salt_rounds),
  );
  const result = await User.findOneAndUpdate(
    { _id: userData?._id, username: userData?.username, role: userData?.role },
    {
      password: newHashedPassword,
      needsPasswordChange: false,
      passwordChangedAt: new Date(),
    },
  );
  return result?.passwordChangedAt;
};

export const authServices = {
  login,
  RefreshToken,
  ChangePassword,
};
