import express from "express";
import { validation } from "../../middleware/validation";
import { authValidation } from "./auth.validation";
import { authController } from "./auth.controller";
import auth from "../../middleware/auth";
import { user_role } from "../user/user.const";
const router = express.Router();
router.post(
  "/login",
  validation(authValidation.authValidationSchema),
  authController.UserLogin,
);

router.post(
  "/refresh-token",
  validation(authValidation.refreshTokenValidationSchema),
  authController.refreshToken,
);

router.post(
  "/change-password",
  auth(user_role.admin, user_role.teacher, user_role.staff, user_role.student),
  validation(authValidation.changePasswordValidationSchema),
  authController.changePassword,
);
export const authRoute = router;
